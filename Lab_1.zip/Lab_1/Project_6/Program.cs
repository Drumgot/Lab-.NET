﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhập a: ");
            double a = double.Parse(Console.ReadLine());
            Console.Write("Nhập b: ");
            double b = double.Parse(Console.ReadLine());
            Console.Write("Nhập c: ");
            double c = double.Parse(Console.ReadLine());

            if (a == 0)
            {
                if (b == 0)
                    Console.WriteLine(c == 0 ? "Phương trình có vô số nghiệm." : "Phương trình vô nghiệm.");
                else
                    Console.WriteLine("Nghiệm x = {0:F2}", -c / b);
            }
            else
            {
                double delta = b * b - 4 * a * c;

                if (delta < 0)
                    Console.WriteLine("Phương trình vô nghiệm.");
                else if (delta == 0)
                    Console.WriteLine("Nghiệm kép x = {0:F2}", -b / (2 * a));
                else
                {
                    Console.WriteLine("x1 = {0:F2}", (-b + Math.Sqrt(delta)) / (2 * a));
                    Console.WriteLine("x2 = {0:F2}", (-b - Math.Sqrt(delta)) / (2 * a));
                }
            }
        }
    }
}

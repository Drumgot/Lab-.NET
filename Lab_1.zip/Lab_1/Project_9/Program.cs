﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhập số từ 0 đến 99: ");
            int so = int.Parse(Console.ReadLine());

            if (so < 0 || so > 99)
            {
                Console.WriteLine("Số phải nằm trong khoảng từ 0 đến 99.");
                return;
            }

            string cachDoc = "";

            if (so < 10)
            {
                switch (so)
                {
                    case 0: cachDoc = "không"; break;
                    case 1: cachDoc = "một"; break;
                    case 2: cachDoc = "hai"; break;
                    case 3: cachDoc = "ba"; break;
                    case 4: cachDoc = "bốn"; break;
                    case 5: cachDoc = "năm"; break;
                    case 6: cachDoc = "sáu"; break;
                    case 7: cachDoc = "bảy"; break;
                    case 8: cachDoc = "tám"; break;
                    case 9: cachDoc = "chín"; break;
                }
            }
            else
            {
                int hangChuc = so / 10;
                int hangDonVi = so % 10;

                switch (hangChuc)
                {
                    case 1: cachDoc = "mười"; break;
                    case 2: cachDoc = "hai mươi"; break;
                    case 3: cachDoc = "ba mươi"; break;
                    case 4: cachDoc = "bốn mươi"; break;
                    case 5: cachDoc = "năm mươi"; break;
                    case 6: cachDoc = "sáu mươi"; break;
                    case 7: cachDoc = "bảy mươi"; break;
                    case 8: cachDoc = "tám mươi"; break;
                    case 9: cachDoc = "chín mươi"; break;
                }

                switch (hangDonVi)
                {
                    case 1: cachDoc += hangChuc == 1 ? " một" : " mốt"; break;
                    case 2: cachDoc += " hai"; break;
                    case 3: cachDoc += " ba"; break;
                    case 4: cachDoc += hangChuc == 1 ? " bốn" : " tư"; break;
                    case 5: cachDoc += " lăm"; break;
                    case 6: cachDoc += " sáu"; break;
                    case 7: cachDoc += " bảy"; break;
                    case 8: cachDoc += " tám"; break;
                    case 9: cachDoc += " chín"; break;
                }
            }

            Console.WriteLine(cachDoc);
        }
    }
}

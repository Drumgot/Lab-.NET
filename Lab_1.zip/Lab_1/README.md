# LAB 1 — Làm quen Visual Studio và Lập trình Console (C#)
## Cách chạy của từng bài
| Bài | Luồng hoạt động |
|-----|-----------------|
| 1 | Nhập họ tên + năm sinh → lấy năm hiện tại trừ năm sinh → in lời chào kèm tuổi 
| 2 | Nhập bán kính `r`, chiều cao `h` → tính `Sxq = 2πrh`, `V = πr²h` → in kết quả 
| 3 | Nhập điểm (0–10) → so sánh với các mốc 9/8/6.5/5 → in xếp loại tương ứng 
| 4 | Hiện menu lặp: chọn `1` → nhập n, cộng dồn 1..n; chọn `2` → in bảng cửu chương 7; chọn `0` → thoát 
| 5 | Nhập a, b → tính `a/b`. Dùng `try-catch` bắt lỗi nhập sai kiểu hoặc chia cho 0, `finally` luôn in "Kết thúc" 
| 6 | Nhập a, b, c → tính delta = b²−4ac → nếu delta < 0: vô nghiệm, = 0: nghiệm kép, > 0: hai nghiệm 
| 7 | Nhập n số → vừa nhập vừa cộng dồn tổng, so sánh tìm max/min, đếm số chẵn → in thống kê 
| 8 | Nhập n → duyệt từ 2 đến n, kiểm tra ước từ 2 đến √số → lưu và in các số nguyên tố 
| 9 | Nhập số (0–99) → tách hàng chục/đơn vị → dùng `switch-case` ghép chuỗi chữ tiếng Việt 
| 10 | Chọn 1 trong 3 kiểu hình → dùng vòng lặp lồng nhau, kiểm tra vị trí viền/rỗng → in `*` hoặc khoảng trắng 

## Danh sách bài tập & Dữ liệu thử

### Bài 1 — Chào hỏi và tính tuổi
Chức năng: Nhập họ tên và năm sinh → in lời chào kèm tuổi gần đúng.

| Dữ liệu nhập          | Kết quả                                              |
|------------------------|------------------------------------------------------|
| Tên: `Nguyễn Văn A`   | `Xin chào Nguyễn Văn A, tuổi gần đúng của bạn là: 26` |
| Năm sinh: `2000`      |                                                      |
### Bài 2 — Diện tích xung quanh & thể tích hình trụ
Chức năng: Nhập bán kính `r` và chiều cao `h` → tính diện tích xung quanh và thể tích hình trụ.

| Dữ liệu nhập | Kết quả                   |
|---------------|---------------------------|
| r = `3`       | `Sxq = 18.85; V = 28.27` |
| h = `1`       |                           |
### Bài 3 — Xếp loại điểm
**Chức năng:** Nhập điểm (0–10) → xếp loại học lực.
| Dữ liệu nhập | Kết quả  |
|---------------|----------|
| Điểm: `8`    | `Giỏi`   |
Quy tắc: ≥ 9 → Xuất sắc, ≥ 8 → Giỏi, ≥ 6.5 → Khá, ≥ 5 → Trung bình, < 5 → Yếu.
### Bài 4 — Menu: Tổng 1..n hoặc Bảng cửu chương 
Chức năng:Hiện menu cho chọn:
- `1` → Nhập n, tính tổng 1 + 2 + ... + n
- `2` → In bảng cửu chương 7
- `0` → Thoát
| Thao tác           | Kết quả                              |
|---------------------|--------------------------------------|
| Chọn `1`, n = `5`  | `Tổng = 15`                          |
| Chọn `2`           | In bảng 7×1=7, 7×2=14, ..., 7×10=70 |
| Chọn `0`           | Thoát chương trình                   |
### Bài 5 — Chia số nguyên có xử lý lỗi
Chức năng: Nhập hai số nguyên a, b → tính a / b. Có bắt lỗi khi nhập sai hoặc chia cho 0.
| Dữ liệu nhập | Kết quả                       |
|---------------|-------------------------------|
| a = `4`       | `a / b = 0`                   |
| b = `8`       | `Kết thúc phép tính.`         |
(Vì 4 / 8 = 0 trong phép chia số nguyên)
### Bài 6 — Giải phương trình bậc 2 
Chức năng: Nhập a, b, c → giải phương trình ax² + bx + c = 0.
| Dữ liệu nhập         | Kết quả                          |
|-----------------------|----------------------------------|
| a=`1`, b=`-5`, c=`6` | `x1 = 3.00` và `x2 = 2.00`     |
| a=`1`, b=`-4`, c=`4` | `Nghiệm kép x = 2.00`          |
| a=`1`, b=`1`, c=`1`  | `Phương trình vô nghiệm.`      |
### Bài 7 — Thống kê dãy số
Chức năng: Nhập n số → tính tổng, trung bình, tìm số lớn nhất, nhỏ nhất, đếm số chẵn.
| Dữ liệu nhập             | Kết quả                                                                 |
|---------------------------|-------------------------------------------------------------------------|
| n = `3`                   | Tổng: `13`                                                              |
| Số 1: `1`, Số 2: `3`, Số 3: `9` | Trung bình: `4.33`, Lớn nhất: `9`, Nhỏ nhất: `1`, Số chẵn: `0` |
### Bài 8 — Liệt kê số nguyên tố
Chức năng:Nhập n → in tất cả số nguyên tố từ 2 đến n.
| Dữ liệu nhập | Kết quả                               |
|---------------|----------------------------------------|
| n = `3`       | `Các số nguyên tố không vượt quá n: 2 3` |
### Bài 9 — Đọc số thành chữ (0–99)
Chức năng:Nhập một số từ 0 đến 99 → đọc thành chữ tiếng Việt.
| Dữ liệu nhập | Kết quả        |
|---------------|----------------|
| Số: `33`      | `ba mươi ba`   |
### Bài 10 — Vẽ hình bằng dấu `*`
Chức năng:Chọn 1 trong 3 hình để vẽ bằng dấu `*` (kích thước 5×5):
- `1` → Tam giác vuông đặc
- `2` → Tam giác vuông rỗng
- `3` → Hình vuông rỗng
| Dữ liệu nhập | Kết quả (ví dụ chọn 3)  |
|---------------|--------------------------|
| Chọn hình: `3` | Vẽ hình vuông rỗng:    |
```
*****
*   *
*   *
*   *
*****
```

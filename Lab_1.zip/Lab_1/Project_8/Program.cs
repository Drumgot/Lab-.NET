﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhập n: ");
            int n = int.Parse(Console.ReadLine());
            if (n < 2)
            {
                Console.WriteLine("Không có số nguyên tố nào.");
                return;
            }
            int[] mangSoNguyenTo = new int[n];
            int soLuong = 0;
            for (int so = 2; so <= n; so++)
            {
                bool laSoNguyenTo = true;
                for (int uoc = 2; uoc * uoc <= so; uoc++)
                {
                    if (so % uoc == 0)
                    {
                        laSoNguyenTo = false;
                        break;
                    }
                }
                if (laSoNguyenTo)
                    mangSoNguyenTo[soLuong++] = so;
            }
            Console.Write("Các số nguyên tố không vượt quá n: ");
            for (int i = 0; i < soLuong; i++)
                Console.Write("{0} ", mangSoNguyenTo[i]);
            Console.WriteLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhập số lượng n: ");
            int n = int.Parse(Console.ReadLine());
            if (n <= 0)
            {
                Console.WriteLine("n phải lớn hơn 0.");
                return;
            }
            long sum = 0;
            int max = int.MinValue;
            int min = int.MaxValue;
            int evenCount = 0;
            for (int i = 1; i <= n; i++)
            {
                Console.Write("Nhập số thứ {0}: ", i);
                int number = int.Parse(Console.ReadLine());
                sum += number;
                if (number > max) max = number;
                if (number < min) min = number;
                if (number % 2 == 0) evenCount++;
            }
            Console.WriteLine("Tổng: {0}", sum);
            Console.WriteLine("Trung bình: {0:F2}", (double)sum / n);
            Console.WriteLine("Số lớn nhất: {0}", max);
            Console.WriteLine("Số nhỏ nhất: {0}", min);
            Console.WriteLine("Số lượng số chẵn: {0}", evenCount);
        }
    }
}
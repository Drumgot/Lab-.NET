﻿using System;

namespace Project_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.Write("Nhập họ và tên: ");
            string hoTen = Console.ReadLine();
            Console.Write("Nhập năm sinh: ");
            int namSinh;
            if (!int.TryParse(Console.ReadLine(), out namSinh))
            {
                Console.WriteLine("Năm sinh của bạn không hợp lệ.");
                return;
            }
            int tuoi = DateTime.Now.Year - namSinh;
            Console.WriteLine("Xin chào {0}, tuổi gần đúng của bạn là: {1}", hoTen, tuoi);
        }
    }
}

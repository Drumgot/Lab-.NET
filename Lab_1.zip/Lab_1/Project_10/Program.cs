﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1. Tam giác vuông đặc");
            Console.WriteLine("2. Tam giác vuông rỗng");
            Console.WriteLine("3. Hình vuông rỗng");
            Console.Write("Chọn hình: ");
            int luaChon = int.Parse(Console.ReadLine());

            if (luaChon < 1 || luaChon > 3)
            {
                Console.WriteLine("Lựa chọn không hợp lệ.");
                return;
            }

            const int kichThuoc = 5;

            switch (luaChon)
            {
                case 1:
                    for (int hang = 1; hang <= kichThuoc; hang++)
                    {
                        for (int cot = 1; cot <= hang; cot++)
                            Console.Write("*");
                        Console.WriteLine();
                    }
                    break;

                case 2:
                    for (int hang = 1; hang <= kichThuoc; hang++)
                    {
                        for (int cot = 1; cot <= hang; cot++)
                        {
                            if (cot == 1 || cot == hang || hang == kichThuoc)
                                Console.Write("*");
                            else
                                Console.Write(" ");
                        }
                        Console.WriteLine();
                    }
                    break;

                case 3:
                    for (int hang = 1; hang <= kichThuoc; hang++)
                    {
                        for (int cot = 1; cot <= kichThuoc; cot++)
                        {
                            if (hang == 1 || hang == kichThuoc || cot == 1 || cot == kichThuoc)
                                Console.Write("*");
                            else
                                Console.Write(" ");
                        }
                        Console.WriteLine();
                    }
                    break;
            }
        }
    }
}
